"""Similarity placeholder."""
