"""Image embedding placeholder."""
