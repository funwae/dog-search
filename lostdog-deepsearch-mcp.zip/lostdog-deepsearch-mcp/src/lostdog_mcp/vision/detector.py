"""Dog detection placeholder."""
