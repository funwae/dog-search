"""Case service placeholder."""
