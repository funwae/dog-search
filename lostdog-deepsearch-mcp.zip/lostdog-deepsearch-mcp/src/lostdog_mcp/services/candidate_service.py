"""Candidate service placeholder."""
