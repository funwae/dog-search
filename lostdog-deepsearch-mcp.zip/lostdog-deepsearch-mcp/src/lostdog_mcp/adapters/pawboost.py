"""PawBoost adapter placeholder."""
