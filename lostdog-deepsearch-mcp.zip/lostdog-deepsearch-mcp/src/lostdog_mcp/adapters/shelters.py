"""Shelter adapter placeholder."""
