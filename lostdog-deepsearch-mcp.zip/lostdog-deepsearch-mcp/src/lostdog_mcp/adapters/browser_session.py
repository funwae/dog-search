"""Browser-session adapter placeholder."""
