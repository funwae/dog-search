"""Public web adapter placeholder."""
