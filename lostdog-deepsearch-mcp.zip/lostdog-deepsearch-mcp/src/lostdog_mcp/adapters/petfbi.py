"""Pet FBI adapter placeholder."""
