from __future__ import annotations

from .config import Settings


def main() -> None:
    settings = Settings.from_env()
    print("LostDog Deep Search MCP starter server")
    print(f"env={settings.env}")
    print(f"db_url={settings.db_url}")
    print(f"browser_session_enabled={settings.enable_browser_session}")
    print("This is a starter placeholder entrypoint. Claude Code should replace it with the real MCP server.")


if __name__ == "__main__":
    main()
