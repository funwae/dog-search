"""ORM model placeholder."""
